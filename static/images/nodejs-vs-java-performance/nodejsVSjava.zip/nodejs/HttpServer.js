var http = require("http");
var mysql      = require('mysql');
var connection = mysql.createConnection({
    host     : 'localhost',
    user     : '',
    password : '',
    database: 'test'
});

http.createServer(function(request, response) {
    //response.writeHead(200, {"Content-Type": "text/plain"});
    //response.write("ok");
    //response.end();

    query(function(rows){
        response.writeHead(200, {"Content-Type": "text/plain"});
        response.write(rows[0].sku_id);
        response.end();
    });
}).listen(8888);

function query(callback){
    var skus = [
        'sku-0000bcd5-c1f7-4460-aaf8-7ee1ab10d409',
        'sku-000f1583-8026-407f-92e2-b6b67c5447e5',
        'sku-000fa572-8f67-4e37-9f2f-52f9bb82a229',
        'sku-0017c850-818b-4bb8-922b-59988b279679',
        'sku-0019ca10-fdb8-490c-a1c7-971b840d0d5f',
        'sku-0019ef1e-0363-41b8-87df-f0f4f51453d0',
        'sku-001a1dd6-cc26-4bfe-a81c-ee952bf024d1',
        'sku-001a475f-45df-4df2-b8bb-643e022b4c72',
        'sku-001ab267-18c6-43b4-915f-104eef32c336',
        'sku-0020b18b-8e09-4d3d-8920-97b27e2d11c4'
    ];

    var sku = skus[Math.floor(Math.random() * 6) + 1];
    connection.query("select * from purch_sku_master where sku_id = '"+sku+"'", function(err, rows, fields) {
        callback(rows);
    });
}
